# openbayes-mnist-example

在 [openbayes](https://openbayes.com) 执行任务的实例。