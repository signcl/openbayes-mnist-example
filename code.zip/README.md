# OpenBayes MNIST Example

OpenBayes MNIST 样例项目

使用方法请参考：[OpenBayes - 快速开始](https://openbayes.com/docs/quickstart/)
